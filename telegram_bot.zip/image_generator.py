import os
from openai import OpenAI
import requests
from io import BytesIO
from PIL import Image
import config

class ImageGenerator:
    def __init__(self):
        # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
        self.client = OpenAI()  # Will automatically use OPENAI_API_KEY from environment

    def generate_image(self, prompt):
        try:
            # Generate image using DALL-E
            response = self.client.images.generate(
                model="dall-e-3",
                prompt=prompt,
                n=1,
                size="1024x1024"
            )

            # Download the generated image
            image_url = response.data[0].url
            response = requests.get(image_url)
            if response.status_code != 200:
                raise Exception("Failed to download generated image")

            # Convert to PIL Image
            image = Image.open(BytesIO(response.content))
            return image

        except Exception as e:
            raise Exception(f"Image generation failed: {str(e)}")